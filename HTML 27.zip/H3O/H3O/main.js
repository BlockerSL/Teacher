function sahand(){
   var H3O = document.getElementById("H3O").value;
   var K = Math.pow(10,H3O);
   var PH = Math.log10(K);
   var POH = 14 - PH;
   var OH = Math.pow(10, -POH);
   
    document.getElementById("PH").value =PH;
        document.getElementById("POH").value =POH;
                document.getElementById("OH").value =OH;


}
