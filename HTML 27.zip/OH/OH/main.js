function sahand(){
   var OH = document.getElementById("OH").value;
   var K = Math.pow(10,OH);
   var POH = Math.log10(K);
   var PH = 14 - POH;
   var H3O = Math.pow(10,-PH);
   
    document.getElementById("H3O").value =H3O;
        document.getElementById("POH").value =POH;
                document.getElementById("PH").value =PH;


}
