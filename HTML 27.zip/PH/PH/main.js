function sahand(){
   var PH = document.getElementById("PH").value;
   var POH = 14 - PH;
   var OH = Math.pow(10, -POH);
   var H3O = Math.pow(10,-PH);
   
    document.getElementById("H3O").value =H3O;
        document.getElementById("POH").value =POH;
                document.getElementById("OH").value =OH;


}
