function sahand(){
   var POH = document.getElementById("POH").value;
   var PH = 14 - POH;
   var OH = Math.pow(10, -POH);
   var H3O = Math.pow(10,-PH);
   
    document.getElementById("H3O").value =H3O;
        document.getElementById("PH").value =PH;
                document.getElementById("OH").value =OH;


}
