function sahand(){
  var Name = document.getElementById("Name").value;
  var M = document.getElementById("M").value;
    var VOH = document.getElementById("VOH").value;
        var VH = document.getElementById("VH").value;
                var NOH = document.getElementById("NOH").value;
        var NH = document.getElementById("NH").value;
//دەسکردن بە شیکار
//کەرەت کردنی دراوی تفت
var A = M*VOH*NOH;
var B = VH*NH;
//دابەش کردنێ دراوی ھەردوو لا

  var C = A/B;
          document.getElementById("Anjam").value=C+" "+"M"+" "+Name;


    var Y = Math.log10(C);
    var T = 14+Y;
    document.getElementById("H3O").value = C;
    document.getElementById("PH").value =Y;
  document.getElementById("POH").value = T;
  document.getElementById("OH").value =  Math.pow(10,-T);
}
